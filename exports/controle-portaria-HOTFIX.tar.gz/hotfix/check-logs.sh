#!/bin/bash
echo "📊 DIAGNÓSTICO COMPLETO"
echo "======================"
echo ""
echo "1️⃣ Verificando código atualizado..."
docker exec controle-portaria-app-1 grep -A2 "filter_var.*ativo.*FILTER_VALIDATE_BOOLEAN" /var/www/html/src/controllers/ConfigController.php | head -3

echo ""
echo "2️⃣ Verificando rota dinâmica no index.php..."
docker exec controle-portaria-app-1 grep -A2 "config/users.*toggle-status" /var/www/html/public/index.php | head -3

echo ""
echo "3️⃣ Logs do container (últimas 30 linhas)..."
docker-compose logs app --tail=30

echo ""
echo "4️⃣ Status do container..."
docker-compose ps

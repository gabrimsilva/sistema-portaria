🔄 PACOTE DE ATUALIZAÇÃO - CORREÇÃO TOGGLE USUÁRIOS
====================================================

Este pacote contém APENAS o código PHP corrigido.
NÃO afeta banco de dados ou usuários existentes.

CORREÇÕES INCLUÍDAS:
✅ Rota /config/users/{id}/toggle-status funcionando
✅ Conversão correta de boolean PostgreSQL
✅ Toggle ativar/inativar usuários funciona 100%

INSTALAÇÃO NA VM UBUNTU:
------------------------

1. Extrair pacote:
   tar -xzf controle-portaria-UPDATE.tar.gz
   cd update-only

2. Executar atualização:
   ./UPDATE.sh

3. Testar:
   - Acessar http://localhost:8080/config
   - Ir na aba "Usuários"
   - Clicar no botão de toggle (Ativo/Inativo)
   - Deve funcionar sem erros!

SEGURANÇA:
----------
✅ Backup automático dos arquivos originais em /tmp/
✅ Zero impacto no banco de dados
✅ Preserva todos os usuários e dados existentes

ROLLBACK (se necessário):
-------------------------
docker cp /tmp/index.php.backup.YYYYMMDD_HHMMSS \
  controle-portaria-app-1:/var/www/html/public/index.php

docker cp /tmp/ConfigController.php.backup.YYYYMMDD_HHMMSS \
  controle-portaria-app-1:/var/www/html/src/controllers/ConfigController.php

docker-compose restart app

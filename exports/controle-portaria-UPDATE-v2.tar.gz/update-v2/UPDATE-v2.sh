#!/bin/bash
echo "🔄 Atualização v2 - Toggle de Usuários (SQL NOT)"
echo "================================================"

# Parar container
echo "⏸️  Parando container..."
docker-compose stop app

# Backup
echo "💾 Criando backup..."
docker cp controle-portaria-app-1:/var/www/html/src/controllers/ConfigController.php /tmp/ConfigController.php.backup.v2.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true

# Copiar arquivo corrigido
echo "📦 Aplicando correção v2..."
docker cp ConfigController.php controle-portaria-app-1:/var/www/html/src/controllers/ConfigController.php

# Permissões
docker exec controle-portaria-app-1 chown www-data:www-data /var/www/html/src/controllers/ConfigController.php

# Limpar cache OPcache
echo "🧹 Limpando cache..."
docker exec controle-portaria-app-1 rm -rf /tmp/opcache-* 2>/dev/null || true

# Reiniciar
echo "🔄 Reiniciando container..."
docker-compose start app
sleep 5

# Limpar OPcache via PHP
docker exec controle-portaria-app-1 bash -c "echo '<?php opcache_reset(); echo \"OK\"; ?>' > /tmp/clear.php && php /tmp/clear.php && rm /tmp/clear.php" 2>/dev/null || true

echo ""
echo "✅ ATUALIZAÇÃO v2 CONCLUÍDA!"
echo ""
echo "📋 MUDANÇA APLICADA:"
echo "   - Usa SQL direto: UPDATE usuarios SET ativo = NOT ativo"
echo "   - Não depende de conversão PHP → PostgreSQL"
echo "   - 100% compatível com qualquer PostgreSQL"
echo ""
echo "🧪 TESTE AGORA:"
echo "   http://localhost:8080/config → Usuários → Toggle"

        </div>
        <!-- /.content-wrapper -->
        
        <!-- Footer -->
        <footer class="main-footer">
            <div class="float-right d-none d-sm-inline">
                Versão 2.0.0
            </div>
            <strong>Sistema de Controle de Acesso</strong> - Renner Coatings
        </footer>
    </div>
    <!-- ./wrapper -->
    
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
    <script src="/assets/js/error-handler.js"></script>
    <script src="/assets/js/pre-cadastros.js"></script>
</body>
</html>

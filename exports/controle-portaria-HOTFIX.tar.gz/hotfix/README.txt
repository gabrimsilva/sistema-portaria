==================================================

PROBLEMA: Código atualizado mas erro persiste
CAUSA: Cache do PHP (OPcache) servindo código antigo

SOLUÇÃO RÁPIDA:
---------------

1. Executar correção automática:
   cd hotfix
   ./fix-cache.sh

2. Se ainda não funcionar, executar diagnóstico:
   ./check-logs.sh

3. Enviar resultado do diagnóstico para análise

O QUE O SCRIPT FAZ:
-------------------
✅ Verifica se código foi atualizado corretamente
✅ Limpa cache do OPcache (código antigo em memória)
✅ Reinicia Apache para forçar reload
✅ Testa conectividade

COMANDOS MANUAIS (se preferir):
--------------------------------

# Limpar cache OPcache
docker exec controle-portaria-app-1 kill -USR2 1

# Reiniciar aplicação
docker-compose restart app

# Ver logs de erro
docker-compose logs app --tail=50 | grep -i error

#!/bin/bash
echo "🔄 Atualizando código PHP corrigido..."

# Parar container
docker-compose stop app

# Fazer backup do código atual
docker cp controle-portaria-app-1:/var/www/html/public/index.php /tmp/index.php.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true
docker cp controle-portaria-app-1:/var/www/html/src/controllers/ConfigController.php /tmp/ConfigController.php.backup.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true

# Copiar arquivos corrigidos
docker cp public/index.php controle-portaria-app-1:/var/www/html/public/index.php
docker cp src/controllers/ConfigController.php controle-portaria-app-1:/var/www/html/src/controllers/ConfigController.php

# Ajustar permissões
docker exec controle-portaria-app-1 chown -R www-data:www-data /var/www/html/public /var/www/html/src

# Reiniciar container
docker-compose start app

echo "✅ Atualização concluída!"
echo "🧪 Teste: http://localhost:8080/config (ir em Usuários e testar toggle)"

========================================

Este pacote configura deploy automático completo:
GitHub push → Build Docker → Deploy Ubuntu Server

CONTEÚDO DO PACOTE:
-------------------
📁 .github/workflows/
   ├── deploy.yml (deploy automático)
   └── test.yml (testes automáticos)

📁 deploy/
   ├── DEPLOY-GUIDE.txt (guia completo detalhado)
   ├── setup-server.sh (configuração automática do servidor)
   ├── docker-compose.prod.yml (Docker para produção)
   └── .env.example (template de configuração)

📄 Dockerfile (imagem Docker da aplicação)

INÍCIO RÁPIDO:
--------------

1. Leia o guia completo:
   cat deploy/DEPLOY-GUIDE.txt

2. Siga os 5 passos:
   ✅ Criar conta Docker Hub
   ✅ Configurar servidor (setup-server.sh)
   ✅ Adicionar secrets no GitHub
   ✅ Preparar primeiro deploy
   ✅ Fazer push

3. Resultado:
   ✅ Deploy automático em ~5 minutos
   ✅ Cada push atualiza o servidor
   ✅ Testes automáticos
   ✅ Zero downtime

TEMPO ESTIMADO DE CONFIGURAÇÃO:
--------------------------------
Primeira vez: ~30 minutos
Próximos deploys: automático! (só fazer git push)

REQUISITOS:
-----------
✅ Conta Docker Hub (grátis)
✅ Repositório GitHub
✅ Servidor Ubuntu 24.04 com SSH
✅ Docker instalado no servidor

SUPORTE:
--------
Todos os passos estão detalhados em:
deploy/DEPLOY-GUIDE.txt

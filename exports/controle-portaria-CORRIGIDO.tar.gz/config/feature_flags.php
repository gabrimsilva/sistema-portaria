<?php

return [
    'USE_REGISTRO_ACESSO' => true
];

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= CSRFProtection::generateToken() ?>">
    <title>Dashboard - Sistema de Controle de Acesso</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/assets/css/dashboard-autocomplete.css?v=<?= time() ?>">
    <style>
        /* Garantir que o dropdown do autocomplete apareça por cima do modal */
        .ui-autocomplete {
            z-index: 1060 !important;
            max-height: 300px;
            overflow-y: auto;
            overflow-x: hidden;
        }
        
        /* Estilizar os itens do autocomplete para combinar com o tema */
        .ui-menu-item {
            font-size: 14px;
        }
        
        .ui-menu-item-wrapper {
            padding: 8px 12px;
        }
        
        .ui-state-active {
            background-color: #007bff !important;
            border-color: #007bff !important;
            color: white !important;
        }
    </style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button">
                        <i class="fas fa-bars"></i>
                    </a>
                </li>
            </ul>
            
            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link" data-toggle="dropdown" href="#">
                        <i class="far fa-user"></i>
                        <span class="d-none d-md-inline"><?= htmlspecialchars($_SESSION['user_name'] ?? 'Usuário') ?></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                        <span class="dropdown-item-text"><?= htmlspecialchars($_SESSION['user_profile'] ?? 'Porteiro') ?></span>
                        <div class="dropdown-divider"></div>
                        <a href="/logout" class="dropdown-item">
                            <i class="fas fa-sign-out-alt mr-2"></i>Sair
                        </a>
                    </div>
                </li>
            </ul>
        </nav>
        
        <!-- 🎯 NavigationService: Navegação Unificada -->
        <?= NavigationService::renderSidebar() ?>
        
        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Dashboard</h1>
                        </div>
                    </div>
                </div>
            </div>
            
            <section class="content">
                <div class="container-fluid">
                    <!-- Statistics Cards -->
                    <div class="row">
                        <!-- Card VERDE: Visitante -->
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3><?= $stats['visitante_ativos'] ?? 0 ?></h3>
                                    <p>Visitante - Ativos Agora</p>
                                    <small class="text-light">
                                        <i class="fas fa-clock"></i> Registrados Hoje: <?= $stats['visitante_hoje'] ?? 0 ?>
                                    </small>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-users"></i>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Card AZUL: Profissional Renner -->
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-primary">
                                <div class="inner">
                                    <h3><?= $stats['profissional_ativos'] ?? 0 ?></h3>
                                    <p>Profissional Renner - Ativos Agora</p>
                                    <small class="text-light">
                                        <i class="fas fa-clock"></i> Registrados Hoje: <?= $stats['profissional_hoje'] ?? 0 ?>
                                    </small>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-id-badge"></i>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Card AMARELO: Prestador de Serviço -->
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-warning">
                                <div class="inner">
                                    <h3><?= $stats['prestador_ativos'] ?? 0 ?></h3>
                                    <p>Prestador de Serviço - Ativos Agora</p>
                                    <small class="text-white">
                                        <i class="fas fa-clock"></i> Registrados Hoje: <?= $stats['prestador_hoje'] ?? 0 ?>
                                    </small>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-tools"></i>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Card VERMELHO: Total -->
                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-danger">
                                <div class="inner">
                                    <h3><?= $stats['total_ativos'] ?? 0 ?></h3>
                                    <p>Total - Ativos Agora</p>
                                    <small class="text-light">
                                        <i class="fas fa-clock"></i> Registrados Hoje: <?= $stats['total_registrados_hoje'] ?? 0 ?>
                                    </small>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-building"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Botões de Cadastro Rápido -->
                    <div class="row mb-3">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-plus-circle"></i> Cadastro Rápido
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4 mb-2">
                                            <button type="button" class="btn btn-success btn-block" data-toggle="modal" data-target="#modalVisitante">
                                                <i class="fas fa-users"></i> Registrar Visitante
                                            </button>
                                        </div>
                                        <div class="col-md-4 mb-2">
                                            <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#modalProfissional">
                                                <i class="fas fa-user-tie"></i> Registrar Profissional Renner
                                            </button>
                                        </div>
                                        <div class="col-md-4 mb-2">
                                            <button type="button" class="btn btn-warning btn-block" data-toggle="modal" data-target="#modalPrestador">
                                                <i class="fas fa-tools"></i> Registrar Prestador de Serviço
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Widget: Cadastros Expirando (v2.0.0) -->
                    <?php if (!empty($cadastrosExpirando['visitantes']) || !empty($cadastrosExpirando['prestadores'])): ?>
                    <div class="row mb-3">
                        <div class="col-12">
                            <div class="card card-warning">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-exclamation-triangle"></i> Cadastros Expirando (Próximos 30 dias)
                                    </h3>
                                    <div class="card-tools">
                                        <span class="badge badge-warning" id="total-expirando">
                                            <?= (count($cadastrosExpirando['visitantes'] ?? []) + count($cadastrosExpirando['prestadores'] ?? [])) ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <ul class="nav nav-tabs" id="expiring-tabs" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="visitantes-expiring-tab" data-toggle="tab" href="#visitantes-expiring" role="tab">
                                                Visitantes <span class="badge badge-success"><?= count($cadastrosExpirando['visitantes'] ?? []) ?></span>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="prestadores-expiring-tab" data-toggle="tab" href="#prestadores-expiring" role="tab">
                                                Prestadores <span class="badge badge-warning"><?= count($cadastrosExpirando['prestadores'] ?? []) ?></span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="tab-content mt-3" id="expiring-tabs-content">
                                        <!-- Visitantes Tab -->
                                        <div class="tab-pane fade show active" id="visitantes-expiring" role="tabpanel">
                                            <?php if (!empty($cadastrosExpirando['visitantes'])): ?>
                                                <div class="table-responsive">
                                                    <table class="table table-sm table-hover">
                                                        <thead>
                                                            <tr>
                                                                <th>Nome</th>
                                                                <th>Documento</th>
                                                                <th>Empresa</th>
                                                                <th>Validade</th>
                                                                <th>Dias Restantes</th>
                                                                <th>Ações</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach ($cadastrosExpirando['visitantes'] as $visitante): ?>
                                                                <tr>
                                                                    <td><?= htmlspecialchars($visitante['nome']) ?></td>
                                                                    <td>
                                                                        <small class="text-muted">
                                                                            <?= htmlspecialchars($visitante['doc_type'] ?? 'CPF') ?>: 
                                                                            <?= htmlspecialchars($visitante['doc_number'] ?? '-') ?>
                                                                        </small>
                                                                    </td>
                                                                    <td><?= htmlspecialchars($visitante['empresa'] ?? '-') ?></td>
                                                                    <td><?= date('d/m/Y', strtotime($visitante['data_validade'])) ?></td>
                                                                    <td>
                                                                        <span class="badge <?= $visitante['dias_restantes'] <= 7 ? 'badge-danger' : 'badge-warning' ?>">
                                                                            <?= $visitante['dias_restantes'] ?> dias
                                                                        </span>
                                                                    </td>
                                                                    <td>
                                                                        <button class="btn btn-sm btn-primary renovar-cadastro" 
                                                                                data-tipo="visitante" 
                                                                                data-id="<?= $visitante['id'] ?>"
                                                                                data-nome="<?= htmlspecialchars($visitante['nome']) ?>">
                                                                            <i class="fas fa-sync"></i> Renovar
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            <?php else: ?>
                                                <p class="text-muted">Nenhum visitante com cadastro expirando nos próximos 30 dias.</p>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <!-- Prestadores Tab -->
                                        <div class="tab-pane fade" id="prestadores-expiring" role="tabpanel">
                                            <?php if (!empty($cadastrosExpirando['prestadores'])): ?>
                                                <div class="table-responsive">
                                                    <table class="table table-sm table-hover">
                                                        <thead>
                                                            <tr>
                                                                <th>Nome</th>
                                                                <th>Documento</th>
                                                                <th>Empresa</th>
                                                                <th>Validade</th>
                                                                <th>Dias Restantes</th>
                                                                <th>Ações</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach ($cadastrosExpirando['prestadores'] as $prestador): ?>
                                                                <tr>
                                                                    <td><?= htmlspecialchars($prestador['nome']) ?></td>
                                                                    <td>
                                                                        <small class="text-muted">
                                                                            <?= htmlspecialchars($prestador['doc_type'] ?? 'CPF') ?>: 
                                                                            <?= htmlspecialchars($prestador['doc_number'] ?? '-') ?>
                                                                        </small>
                                                                    </td>
                                                                    <td><?= htmlspecialchars($prestador['empresa'] ?? '-') ?></td>
                                                                    <td><?= date('d/m/Y', strtotime($prestador['data_validade'])) ?></td>
                                                                    <td>
                                                                        <span class="badge <?= $prestador['dias_restantes'] <= 7 ? 'badge-danger' : 'badge-warning' ?>">
                                                                            <?= $prestador['dias_restantes'] ?> dias
                                                                        </span>
                                                                    </td>
                                                                    <td>
                                                                        <button class="btn btn-sm btn-primary renovar-cadastro" 
                                                                                data-tipo="prestador" 
                                                                                data-id="<?= $prestador['id'] ?>"
                                                                                data-nome="<?= htmlspecialchars($prestador['nome']) ?>">
                                                                            <i class="fas fa-sync"></i> Renovar
                                                                        </button>
                                                                    </td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            <?php else: ?>
                                                <p class="text-muted">Nenhum prestador com cadastro expirando nos próximos 30 dias.</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Pessoas Atualmente na Empresa -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">
                                        <i class="fas fa-building"></i> Pessoas Atualmente na Empresa
                                        <span class="badge badge-info ml-2"><?= isset($pessoasNaEmpresa) ? count($pessoasNaEmpresa) : 0 ?></span>
                                    </h3>
                                </div>
                                <div class="card-body">
                                    <!-- Filtros Avançados -->
                                    <div class="row mb-3">
                                        <div class="col-md-8">
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                                </div>
                                                <input type="text" class="form-control" id="filtro-pessoas" placeholder="Buscar por nome, documento, empresa ou setor...">
                                                <div class="input-group-append">
                                                    <button class="btn btn-outline-secondary" type="button" id="limpar-filtros">
                                                        <i class="fas fa-times"></i> Limpar
                                                    </button>
                                                </div>
                                            </div>
                                            <small class="text-muted">Digite pelo menos 2 caracteres para filtrar por texto</small>
                                        </div>
                                        <div class="col-md-4">
                                            <select class="form-control" id="filtro-tipo">
                                                <option value="">🔍 Todos os Tipos</option>
                                                <option value="Visitante">🟢 Visitante</option>
                                                <option value="Profissional Renner">🔵 Profissional Renner</option>
                                                <option value="Prestador">🟡 Prestador de Serviço</option>
                                            </select>
                                            <small class="text-muted">Filtrar por tipo de registro</small>
                                        </div>
                                    </div>
                                    
                                    <div class="table-responsive">
                                        <?php if (isset($pessoasNaEmpresa) && !empty($pessoasNaEmpresa)): ?>
                                        <table class="table table-hover text-nowrap">
                                            <thead>
                                                <tr>
                                                    <th>Nome</th>
                                                    <th>Tipo</th>
                                                    <th>Documento</th>
                                                    <th>Empresa</th>
                                                    <th>Setor</th>
                                                    <th>Responsável</th>
                                                    <th>Placa</th>
                                                    <th>Hora de Entrada</th>
                                                    <th width="100">Ações</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($pessoasNaEmpresa as $pessoa): ?>
                                                <tr>
                                                    <td>
                                                        <strong><?= htmlspecialchars($pessoa['nome']) ?></strong>
                                                        <?php if (isset($pessoa['is_brigadista']) && $pessoa['is_brigadista'] === true): ?>
                                                            <span class="badge badge-danger ml-2" title="Brigadista de Incêndio">
                                                                <i class="fas fa-fire-extinguisher"></i> Brigadista
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php 
                                                        $badgeClass = '';
                                                        switch ($pessoa['tipo']) {
                                                            case 'Visitante':
                                                                $badgeClass = 'success';
                                                                break;
                                                            case 'Prestador':
                                                                $badgeClass = 'warning';
                                                                break;
                                                            case 'Profissional Renner':
                                                                $badgeClass = 'primary';
                                                                break;
                                                        }
                                                        ?>
                                                        <span class="badge badge-<?= $badgeClass ?>">
                                                            <?= htmlspecialchars($pessoa['tipo']) ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php 
                                                        // Priorizar doc_number, fallback para cpf legado
                                                        $documento = !empty($pessoa['doc_number']) ? $pessoa['doc_number'] : ($pessoa['cpf'] ?? '');
                                                        echo !empty($documento) ? htmlspecialchars($documento) : '-';
                                                        ?>
                                                    </td>
                                                    <td><?= !empty($pessoa['empresa']) ? htmlspecialchars($pessoa['empresa']) : '-' ?></td>
                                                    <td><?= !empty($pessoa['setor']) ? htmlspecialchars($pessoa['setor']) : '-' ?></td>
                                                    <td>
                                                        <?php if (($pessoa['tipo'] === 'Visitante' || $pessoa['tipo'] === 'Prestador') && !empty($pessoa['funcionario_responsavel'])): ?>
                                                            <i class="fas fa-user-tie text-primary mr-1"></i>
                                                            <?= htmlspecialchars($pessoa['funcionario_responsavel']) ?>
                                                        <?php else: ?>
                                                            -
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if (!empty($pessoa['placa_veiculo'])): ?>
                                                            <i class="fas fa-car text-muted mr-1"></i>
                                                            <?= htmlspecialchars($pessoa['placa_veiculo']) ?>
                                                        <?php else: ?>
                                                            -
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if ($pessoa['hora_entrada']): ?>
                                                            <i class="fas fa-clock text-muted"></i>
                                                            <?= date('d/m/Y H:i', strtotime($pessoa['hora_entrada'])) ?>
                                                        <?php else: ?>
                                                            -
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-sm btn-info btn-editar" 
                                                                data-id="<?= $pessoa['id'] ?>" 
                                                                data-tipo="<?= htmlspecialchars($pessoa['tipo']) ?>"
                                                                data-nome="<?= htmlspecialchars($pessoa['nome']) ?>"
                                                                data-cpf="<?= htmlspecialchars($pessoa['cpf'] ?? '') ?>"
                                                                data-doc_type="<?= htmlspecialchars($pessoa['doc_type'] ?? '') ?>"
                                                                data-doc_number="<?= htmlspecialchars($pessoa['doc_number'] ?? '') ?>"
                                                                data-doc_country="<?= htmlspecialchars($pessoa['doc_country'] ?? '') ?>"
                                                                data-empresa="<?= htmlspecialchars($pessoa['empresa'] ?? '') ?>"
                                                                data-setor="<?= htmlspecialchars($pessoa['setor'] ?? '') ?>"
                                                                data-placa_veiculo="<?= htmlspecialchars($pessoa['placa_veiculo'] ?? '') ?>"
                                                data-funcionario_responsavel="<?= htmlspecialchars($pessoa['funcionario_responsavel'] ?? '') ?>"
                                                                title="Editar registro">
                                                            <i class="fas fa-edit"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    <?php else: ?>
                                        <div class="text-center p-4">
                                            <i class="fas fa-building text-muted" style="font-size: 3rem;"></i>
                                            <p class="text-muted mt-2">Nenhuma pessoa está registrada na empresa no momento.</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    
    <!-- Modal para Cadastro de Visitante -->
    <div class="modal fade" id="modalVisitante" tabindex="-1" role="dialog" aria-labelledby="modalVisitanteLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-success">
                    <h5 class="modal-title text-white" id="modalVisitanteLabel">
                        <i class="fas fa-users"></i> Cadastrar Visitante
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="formVisitante">
                        <input type="hidden" name="csrf_token" value="<?= CSRFProtection::generateToken() ?>">
                        <input type="hidden" id="visitante_cadastro_id" name="cadastro_id" value="">
                        <div class="form-group">
                            <label for="visitante_nome">Nome Completo * <small class="text-muted">(Digite para buscar pré-cadastro)</small></label>
                            <input type="text" class="form-control" id="visitante_nome" name="nome" required>
                        </div>
                        
                        <!-- Seletor de Tipo de Documento -->
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="visitante_doc_type">Tipo de Documento</label>
                                    <select class="form-control" id="visitante_doc_type" name="doc_type">
                                        <option value="">CPF (padrão)</option>
                                        <optgroup label="🇧🇷 Documentos Brasileiros">
                                            <option value="CPF">CPF</option>
                                            <option value="RG">RG</option>
                                            <option value="CNH">CNH</option>
                                        </optgroup>
                                        <optgroup label="🌎 Documentos Internacionais">
                                            <option value="Passaporte">Passaporte</option>
                                            <option value="RNE">RNE</option>
                                            <option value="DNI">DNI</option>
                                            <option value="CI">CI</option>
                                            <option value="Outros">Outros</option>
                                        </optgroup>
                                    </select>
                                    <small class="form-text text-muted">Deixe vazio para CPF</small>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label for="visitante_doc_number">Número do Documento *</label>
                                    <input type="text" class="form-control" id="visitante_doc_number" name="doc_number" placeholder="Digite o número" required>
                                    <small class="form-text text-muted">Máscara automática por tipo</small>
                                </div>
                            </div>
                            <div class="col-md-3" id="visitante_country_container" style="display: none;">
                                <div class="form-group">
                                    <label for="visitante_doc_country">País</label>
                                    <input type="text" class="form-control" id="visitante_doc_country" name="doc_country" placeholder="BR" maxlength="2">
                                    <small class="form-text text-muted">Código ISO</small>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Campo CPF legado (hidden, preenchido via JS) -->
                        <input type="hidden" id="visitante_cpf" name="cpf">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="visitante_empresa">Empresa</label>
                                    <input type="text" class="form-control" id="visitante_empresa" name="empresa">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="visitante_setor">Setor *</label>
                                    <input type="text" class="form-control" id="visitante_setor" name="setor" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="visitante_funcionario_responsavel">Funcionário Responsável</label>
                                    <input type="text" class="form-control" id="visitante_funcionario_responsavel" name="funcionario_responsavel">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="visitante_placa_veiculo">Placa de Veículo *</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" id="visitante_placa_veiculo" name="placa_veiculo" placeholder="ABC-1234" style="text-transform: uppercase;" maxlength="8" required>
                                        <span class="input-group-text">
                                            <input type="checkbox" id="visitante_ape_checkbox">
                                            <label for="visitante_ape_checkbox" class="ml-1 mb-0">A pé</label>
                                        </span>
                                    </div>
                                    <small class="form-text text-muted">Marque "A pé" se não houver veículo</small>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="visitante_hora_entrada">Hora de Entrada</label>
                            <input type="datetime-local" class="form-control" id="visitante_hora_entrada" name="hora_entrada" required>
                            <small class="form-text text-muted">Hora atual preenchida automaticamente, mas pode ser editada</small>
                        </div>
                        
                        <!-- Visualização de Foto (se cadastrado) -->
                        <div class="form-group" id="visitante-photo-display" style="display: none;">
                            <label>📸 Foto do Cadastro</label>
                            <div class="text-center">
                                <img id="visitante-foto-preview" src="" alt="Foto do visitante" class="img-thumbnail" style="max-width: 200px; max-height: 200px;">
                            </div>
                            <small class="form-text text-muted">Foto capturada no pré-cadastro</small>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-success" id="btnSalvarVisitante">
                        <i class="fas fa-save"></i> Cadastrar Visitante
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal para Cadastro de Profissional Renner -->
    <div class="modal fade" id="modalProfissional" tabindex="-1" role="dialog" aria-labelledby="modalProfissionalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <h5 class="modal-title text-white" id="modalProfissionalLabel">
                        <i class="fas fa-user-tie"></i> Cadastrar Profissional Renner
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="formProfissional">
                        <input type="hidden" name="csrf_token" value="<?= CSRFProtection::generateToken() ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="profissional_nome">Nome Completo *</label>
                                    <input type="text" class="form-control" id="profissional_nome" name="nome" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="profissional_setor">Setor *</label>
                                    <input type="text" class="form-control" id="profissional_setor" name="setor" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="profissional_placa_veiculo">Placa de Veículo *</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="profissional_placa_veiculo" name="placa_veiculo" placeholder="ABC-1234" style="text-transform: uppercase;" maxlength="8" required>
                                <span class="input-group-text">
                                    <input type="checkbox" id="profissional_ape_checkbox">
                                    <label for="profissional_ape_checkbox" class="ml-1 mb-0">A pé</label>
                                </span>
                            </div>
                            <small class="form-text text-muted">Marque "A pé" se não houver veículo</small>
                        </div>
                        <div class="form-group">
                            <label for="profissional_data_entrada">Data/Hora de Entrada</label>
                            <input type="datetime-local" class="form-control" id="profissional_data_entrada" name="data_entrada" required>
                            <small class="form-text text-muted">Hora atual preenchida automaticamente, mas pode ser editada</small>
                        </div>
                        
                        <!-- Campo de Observação para Entrada Retroativa -->
                        <div class="form-group" id="profissional_observacao_container" style="display: none;">
                            <div class="alert alert-warning">
                                <i class="fas fa-exclamation-triangle"></i> <strong>Entrada Retroativa Detectada</strong>
                            </div>
                            <label for="profissional_observacao">Observação/Justificativa *</label>
                            <textarea class="form-control" id="profissional_observacao" name="observacao" rows="3" placeholder="Informe o motivo da entrada retroativa"></textarea>
                            <small class="form-text text-muted">Obrigatório para entradas retroativas</small>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="btnSalvarProfissional">
                        <i class="fas fa-save"></i> Cadastrar Profissional
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal para Cadastro de Prestador de Serviço -->
    <div class="modal fade" id="modalPrestador" tabindex="-1" role="dialog" aria-labelledby="modalPrestadorLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title text-dark" id="modalPrestadorLabel">
                        <i class="fas fa-tools"></i> Cadastrar Prestador de Serviço
                    </h5>
                    <button type="button" class="close text-dark" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="formPrestador">
                        <input type="hidden" name="csrf_token" value="<?= CSRFProtection::generateToken() ?>">
                        <input type="hidden" id="prestador_cadastro_id" name="cadastro_id" value="">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="prestador_nome">Nome Completo * <small class="text-muted">(Digite para buscar pré-cadastro)</small></label>
                                    <input type="text" class="form-control" id="prestador_nome" name="nome" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="prestador_doc_type">Tipo de Documento</label>
                                    <select class="form-control" id="prestador_doc_type" name="doc_type">
                                        <option value="">CPF (padrão)</option>
                                        <optgroup label="🇧🇷 Documentos Brasileiros">
                                            <option value="CPF">CPF</option>
                                            <option value="RG">RG</option>
                                            <option value="CNH">CNH</option>
                                        </optgroup>
                                        <optgroup label="🌎 Documentos Internacionais">
                                            <option value="Passaporte">Passaporte</option>
                                            <option value="RNE">RNE</option>
                                            <option value="DNI">DNI</option>
                                            <option value="CI">CI</option>
                                            <option value="Outros">Outros</option>
                                        </optgroup>
                                    </select>
                                    <small class="text-muted">Deixe vazio para CPF</small>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label for="prestador_doc_number">Número do Documento *</label>
                                    <input type="text" class="form-control" id="prestador_doc_number" name="doc_number" required>
                                    <small class="text-muted">Máscara automática por tipo</small>
                                </div>
                            </div>
                            <div class="col-md-3" id="prestador_country_container" style="display: none;">
                                <div class="form-group">
                                    <label for="prestador_doc_country">País</label>
                                    <input type="text" class="form-control" id="prestador_doc_country" name="doc_country" value="Brasil">
                                </div>
                            </div>
                            
                            <!-- Campo CPF oculto para compatibilidade -->
                            <input type="hidden" id="prestador_cpf" name="cpf">
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="prestador_empresa">Empresa</label>
                                    <input type="text" class="form-control" id="prestador_empresa" name="empresa">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="prestador_setor">Setor *</label>
                                    <input type="text" class="form-control" id="prestador_setor" name="setor" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="prestador_placa_veiculo">Placa de Veículo *</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="prestador_placa_veiculo" name="placa_veiculo" placeholder="ABC-1234" style="text-transform: uppercase;" maxlength="8" required>
                                <span class="input-group-text">
                                    <input type="checkbox" id="prestador_ape_checkbox">
                                    <label for="prestador_ape_checkbox" class="ml-1 mb-0">A pé</label>
                                </span>
                            </div>
                            <small class="form-text text-muted">Marque "A pé" se não houver veículo</small>
                        </div>
                        <div class="form-group">
                            <label for="prestador_funcionario_responsavel">Funcionário Responsável *</label>
                            <input type="text" class="form-control" id="prestador_funcionario_responsavel" name="funcionario_responsavel" required>
                        </div>
                        <div class="form-group">
                            <label for="prestador_observacao">Observações</label>
                            <textarea class="form-control" id="prestador_observacao" name="observacao" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="prestador_entrada">Data/Hora de Entrada</label>
                            <input type="datetime-local" class="form-control" id="prestador_entrada" name="entrada" required>
                            <small class="form-text text-muted">Hora atual preenchida automaticamente, mas pode ser editada</small>
                        </div>
                        
                        <!-- Visualização de Foto (se cadastrado) -->
                        <div class="form-group" id="prestador-photo-display" style="display: none;">
                            <label>📸 Foto do Cadastro</label>
                            <div class="text-center">
                                <img id="prestador-foto-preview" src="" alt="Foto do prestador" class="img-thumbnail" style="max-width: 200px; max-height: 200px;">
                            </div>
                            <small class="form-text text-muted">Foto capturada no pré-cadastro</small>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-warning" id="btnSalvarPrestador">
                        <i class="fas fa-save"></i> Cadastrar Prestador
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal para Edição de Registros -->
    <div class="modal fade" id="modalEditar" tabindex="-1" role="dialog" aria-labelledby="modalEditarLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-info">
                    <h5 class="modal-title text-white" id="modalEditarLabel">
                        <i class="fas fa-edit"></i> Editar Registro
                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="formEditar">
                        <input type="hidden" name="csrf_token" value="<?= CSRFProtection::generateToken() ?>">
                        <input type="hidden" id="edit_id" name="id">
                        <input type="hidden" id="edit_tipo_original" name="tipo_original">
                        
                        <div class="form-group">
                            <label>Tipo de Registro</label>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle"></i> 
                                <span id="edit_tipo_display"></span>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="edit_nome">Nome Completo *</label>
                            <input type="text" class="form-control" id="edit_nome" name="nome" required>
                        </div>
                        
                        <!-- Campos de Documento (para Prestadores e Visitantes) -->
                        <div id="campos_documento" style="display: none;">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="edit_doc_type">Tipo de Documento</label>
                                        <select class="form-control" id="edit_doc_type" name="doc_type">
                                            <option value="CPF">CPF</option>
                                            <option value="RG">RG</option>
                                            <option value="CNH">CNH</option>
                                            <option value="Passaporte">Passaporte</option>
                                            <option value="RNE">RNE</option>
                                            <option value="DNI">DNI</option>
                                            <option value="CI">CI</option>
                                            <option value="Outros">Outros</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label for="edit_doc_number">Número do Documento</label>
                                        <input type="text" class="form-control" id="edit_doc_number" name="doc_number">
                                    </div>
                                </div>
                                <div class="col-md-3" id="edit_country_container" style="display: none;">
                                    <div class="form-group">
                                        <label for="edit_doc_country">País</label>
                                        <input type="text" class="form-control" id="edit_doc_country" name="doc_country" value="Brasil">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div id="campo_empresa" class="col-md-6">
                                <div class="form-group">
                                    <label for="edit_empresa">Empresa</label>
                                    <input type="text" class="form-control" id="edit_empresa" name="empresa">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="edit_setor">Setor</label>
                                    <input type="text" class="form-control" id="edit_setor" name="setor">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Campo Placa de Veículo - visível para Visitantes, Prestadores e Profissionais Renner -->
                        <div id="campo_placa_veiculo" class="form-group" style="display: none;">
                            <label for="edit_placa_veiculo">Placa de Veículo</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="edit_placa_veiculo" name="placa_veiculo" placeholder="ABC-1234" style="text-transform: uppercase;" maxlength="8">
                                <span class="input-group-text">
                                    <input type="checkbox" id="edit_ape_checkbox">
                                    <label for="edit_ape_checkbox" class="ml-1 mb-0">A pé</label>
                                </span>
                            </div>
                            <small class="form-text text-muted">Marque "A pé" se não houver veículo</small>
                        </div>
                        
                        <!-- Campos específicos para visitantes -->
                        <div id="campo_funcionario_responsavel" class="form-group" style="display: none;">
                            <label for="edit_funcionario_responsavel">Funcionário Responsável</label>
                            <input type="text" class="form-control" id="edit_funcionario_responsavel" name="funcionario_responsavel">
                        </div>
                        
                        <!-- Campos específicos para Profissional Renner -->
                        <div id="campos_profissional_renner" style="display: none;">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="edit_saida">Saída Intermediária</label>
                                        <input type="datetime-local" class="form-control" id="edit_saida" name="saida">
                                        <small class="form-text text-muted">Primeira saída durante o expediente</small>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="edit_retorno">Retorno</label>
                                        <input type="datetime-local" class="form-control" id="edit_retorno" name="retorno">
                                        <small class="form-text text-muted">Retorno após saída intermediária</small>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Campo de Observação Editável -->
                            <div class="form-group">
                                <label for="edit_profissional_observacao_geral">Observações</label>
                                <textarea class="form-control" id="edit_profissional_observacao_geral" name="observacao" rows="3" placeholder="Informações adicionais sobre o registro"></textarea>
                                <small class="form-text text-muted">Observações gerais sobre o acesso do profissional</small>
                            </div>
                            
                            <!-- Campo de Observação para Entrada Retroativa (somente leitura) -->
                            <div class="form-group" id="edit_profissional_observacao_container" style="display: none;">
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle"></i> <strong>Entrada Retroativa</strong>
                                </div>
                                <label for="edit_profissional_observacao">Justificativa da Entrada Retroativa</label>
                                <textarea class="form-control" id="edit_profissional_observacao" name="observacao_retroativa" rows="3" readonly></textarea>
                                <small class="form-text text-muted">Registro da justificativa da entrada retroativa</small>
                            </div>
                        </div>
                        
                        <div id="campo_hora_saida" class="form-group" style="display: none;">
                            <label for="edit_hora_saida">Hora de Saída</label>
                            <input type="datetime-local" class="form-control" id="edit_hora_saida" name="hora_saida">
                            <small class="form-text text-muted">Deixe em branco se a pessoa ainda não saiu da empresa</small>
                        </div>
                        
                        <!-- Campo específico para prestadores -->
                        <div id="campo_observacao" class="form-group" style="display: none;">
                            <label for="edit_observacao">Observações</label>
                            <textarea class="form-control" id="edit_observacao" name="observacao" rows="3"></textarea>
                        </div>
                        
                        <!-- 📸 Visualização de Foto (Visitantes e Prestadores) -->
                        <div class="form-group" id="edit-photo-display" style="display: none;">
                            <label>📸 Foto do Cadastro</label>
                            <div class="text-center">
                                <img id="edit-foto-preview" src="" alt="Foto" class="img-thumbnail" style="max-width: 300px; max-height: 300px;">
                            </div>
                            <small class="form-text text-muted">Foto capturada no pré-cadastro</small>
                        </div>

                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-info" id="btnSalvarEdicao">
                        <i class="fas fa-save"></i> Salvar Alterações
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    
    <!-- 🆕 PRÉ-CADASTROS V2.0.0 - Autocomplete -->
    <script src="/assets/js/dashboard-autocomplete.js?v=<?= time() ?>"></script>
    <script src="/assets/js/dashboard-precadastros-autocomplete.js?v=<?= time() ?>"></script>
    <script src="/assets/js/dashboard-placa-autocomplete.js?v=<?= time() ?>"></script>
    <script src="/assets/js/dashboard-documento-autocomplete.js?v=<?= time() ?>"></script>
    
    <!-- 📸 Photo Capture Component -->
    
    <?php
    require_once '../src/services/ErrorHandlerService.php';
    echo ErrorHandlerService::renderComplete();
    ?>
    
    <script>
    $(document).ready(function() {
        // Funções de utilidade
        function showToast(message, type = 'success') {
            const toastClass = type === 'success' ? 'bg-success' : 'bg-danger';
            const toastHtml = `
                <div class="toast ${toastClass} text-white" role="alert" aria-live="assertive" aria-atomic="true" data-delay="3000">
                    <div class="toast-body">
                        ${message}
                    </div>
                </div>
            `;
            
            if (!$('#toast-container').length) {
                $('body').append('<div id="toast-container" style="position: fixed; top: 20px; right: 20px; z-index: 9999;"></div>');
            }
            
            const $toast = $(toastHtml);
            $('#toast-container').append($toast);
            $toast.toast('show');
            
            $toast.on('hidden.bs.toast', function() {
                $(this).remove();
            });
        }
        
        function limparFormulario(formId) {
            $(`#${formId}`)[0].reset();
        }
        
        function atualizarLinhaNaTabela(data) {
            // Função para atualizar registro existente SEM afetar contadores
            const linha = $(`.btn-editar[data-id="${data.id}"]`).closest('tr');
            if (linha.length > 0) {
                // Verificar se a pessoa registrou saída (deve ser removida da lista)
                let temSaida = false;
                
                // Verificar cada tipo de saída possível nos dados retornados pelo controller
                if (data.hora_saida && data.hora_saida !== null && data.hora_saida !== '') {
                    temSaida = true; // Visitante com saída
                } else if (data.saida_final && data.saida_final !== null && data.saida_final !== '') {
                    temSaida = true; // Profissional Renner com saída final
                } else if (data.saida && data.saida !== null && data.saida !== '' && !data.hasOwnProperty('setor')) {
                    // Prestador com saída (só remove se NÃO for Profissional Renner)
                    // Profissionais Renner têm campo 'setor', Prestadores não têm
                    temSaida = true; 
                }
                
                // Se a pessoa saiu, remover da tabela e atualizar contadores
                if (temSaida) {
                    showToast(`${data.nome} saiu da empresa`, 'success');
                    
                    linha.fadeOut(300, function() {
                        $(this).remove();
                        
                        // Atualizar contador de pessoas na empresa
                        const badge = $('.card-title .badge');
                        const contadorAtual = parseInt(badge.text()) || 0;
                        if (contadorAtual > 0) {
                            badge.text(contadorAtual - 1);
                        }
                        
                        // Atualizar contador de saídas hoje
                        const saidasCard = $('.small-box').eq(3).find('.inner h3');
                        const saidasAtual = parseInt(saidasCard.text()) || 0;
                        saidasCard.text(saidasAtual + 1);
                    });
                    
                    return; // Não continuar com a atualização da linha
                }
                
                // Se não saiu, atualizar linha normalmente
                // Define a cor do badge baseado no tipo
                let badgeClass = 'primary';
                if (data.tipo === 'Visitante') badgeClass = 'success';
                else if (data.tipo === 'Prestador') badgeClass = 'warning';
                
                // Formata a data/hora se disponível
                let dataFormatada = '-';
                if (data.hora_entrada) {
                    dataFormatada = new Date(data.hora_entrada.replace(' ', 'T')).toLocaleString('pt-BR', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                }
                
                // Atualiza o conteúdo da linha existente
                linha.html(`
                    <td><strong>${data.nome}</strong></td>
                    <td><span class="badge badge-${badgeClass}">${data.tipo}</span></td>
                    <td>${data.cpf || '-'}</td>
                    <td>${data.empresa || '-'}</td>
                    <td>${data.setor || '-'}</td>
                    <td>${(data.tipo === 'Visitante' || data.tipo === 'Prestador') && data.funcionario_responsavel ? '<i class="fas fa-user-tie text-primary mr-1"></i>' + data.funcionario_responsavel : '-'}</td>
                    <td>${data.placa_veiculo || '-'}</td>
                    <td><i class="fas fa-clock text-muted"></i> ${dataFormatada}</td>
                    <td>
                        <button class="btn btn-sm btn-info btn-editar" 
                                data-id="${data.id}" 
                                data-tipo="${data.tipo}"
                                data-nome="${data.nome}"
                                data-cpf="${data.cpf || ''}"
                                data-empresa="${data.empresa || ''}"
                                data-setor="${data.setor || ''}"
                                data-funcionario_responsavel="${data.funcionario_responsavel || ''}"
                                data-placa_veiculo="${data.placa_veiculo || ''}"
                                title="Editar registro">
                            <i class="fas fa-edit"></i>
                        </button>
                    </td>
                `);
            }
        }

        function adicionarPessoaNaLista(data) {
            // Verifica se há pessoas na lista ou se está vazia
            const tabelaBody = $('.table tbody');
            const emptyMessage = $('.text-center.p-4');
            
            if (emptyMessage.length > 0) {
                // Remove a mensagem de "nenhuma pessoa" e cria a tabela
                emptyMessage.parent().html(`
                    <table class="table table-hover text-nowrap">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Tipo</th>
                                <th>Documento</th>
                                <th>Empresa</th>
                                <th>Setor</th>
                                <th>Responsável</th>
                                <th>Placa</th>
                                <th>Hora de Entrada</th>
                                <th width="100">Ações</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                `);
            }
            
            // Define a cor do badge baseado no tipo
            let badgeClass = 'primary';
            if (data.tipo === 'Visitante') badgeClass = 'success';
            else if (data.tipo === 'Prestador') badgeClass = 'warning';
            
            // Formata a data/hora
            const dataFormatada = new Date(data.hora_entrada.replace(' ', 'T')).toLocaleString('pt-BR', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            // Cria a nova linha
            const novaLinha = `
                <tr>
                    <td><strong>${data.nome}</strong></td>
                    <td><span class="badge badge-${badgeClass}">${data.tipo}</span></td>
                    <td>${data.cpf || '-'}</td>
                    <td>${data.empresa || '-'}</td>
                    <td>${data.setor || '-'}</td>
                    <td>${(data.tipo === 'Visitante' || data.tipo === 'Prestador') && data.funcionario_responsavel ? '<i class="fas fa-user-tie text-primary mr-1"></i>' + data.funcionario_responsavel : '-'}</td>
                    <td>${data.placa_veiculo || '-'}</td>
                    <td><i class="fas fa-clock text-muted"></i> ${dataFormatada}</td>
                    <td>
                        <button class="btn btn-sm btn-info btn-editar" 
                                data-id="${data.id}" 
                                data-tipo="${data.tipo}"
                                data-nome="${data.nome}"
                                data-cpf="${data.cpf || ''}"
                                data-empresa="${data.empresa || ''}"
                                data-setor="${data.setor || ''}"
                                data-funcionario_responsavel="${data.funcionario_responsavel || ''}"
                                data-placa_veiculo="${data.placa_veiculo || ''}"
                                title="Editar registro">
                            <i class="fas fa-edit"></i>
                        </button>
                    </td>
                </tr>
            `;
            
            // Adiciona a linha no topo da tabela
            $('.table tbody').prepend(novaLinha);
            
            // Atualiza o contador no badge "Pessoas Atualmente na Empresa"
            const badge = $('.card-title .badge');
            const contadorAtual = parseInt(badge.text()) || 0;
            badge.text(contadorAtual + 1);
            
            // Atualiza os contadores específicos do dashboard baseado no tipo
            if (data.tipo === 'Visitante') {
                // Primeiro card: Visitantes Hoje
                const visitantesCard = $('.small-box').eq(0).find('.inner h3');
                const visitantesAtual = parseInt(visitantesCard.text()) || 0;
                visitantesCard.text(visitantesAtual + 1);
            } else if (data.tipo === 'Profissional Renner') {
                // Segundo card: Funcionários Ativos
                const funcionariosCard = $('.small-box').eq(1).find('.inner h3');
                const funcionariosAtual = parseInt(funcionariosCard.text()) || 0;
                funcionariosCard.text(funcionariosAtual + 1);
            }
            // Nota: Prestadores de Serviço contam apenas nas "Entradas Hoje", não têm contador específico
            
            // Sempre atualiza o contador de "Entradas Hoje" (terceiro card)
            const entradasCard = $('.small-box').eq(2).find('.inner h3');
            const entradasAtual = parseInt(entradasCard.text()) || 0;
            entradasCard.text(entradasAtual + 1);
        }
        
        // Cadastro de Visitante
        $('#btnSalvarVisitante').click(function() {
            const formData = $('#formVisitante').serialize();
            const nome = $('#visitante_nome').val().trim();
            
            if (!nome) {
                showToast('Nome é obrigatório', 'error');
                return;
            }
            
            $(this).prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Salvando...');
            
            $.ajax({
                url: '/visitantes?action=save_ajax',
                method: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    console.log('📊 Resposta do servidor:', response);
                    if (response.success) {
                        showToast('Visitante cadastrado com sucesso!');
                        $('#modalVisitante').modal('hide');
                        limparFormulario('formVisitante');
                        setTimeout(() => window.location.reload(), 500);
                    } else {
                        console.log('❌ Erro:', response.message, response.errors);
                        // Tratamento melhorado para erros de duplicidade
                        if (response.errors && Array.isArray(response.errors)) {
                            const mensagens = response.errors.join('<br>');
                            showToast(`⚠️ Problema de duplicidade:<br><small>${mensagens}</small>`, 'error');
                        } else {
                            showToast(response.message || 'Erro ao cadastrar visitante', 'error');
                        }
                    }
                },
                error: function(xhr, status, error) {
                    if (xhr.status === 401) {
                        showToast('Sessão expirada. Você será redirecionado para o login.', 'error');
                        setTimeout(() => {
                            window.location.href = '/login';
                        }, 2000);
                    } else {
                        showToast('Erro na comunicação com o servidor', 'error');
                    }
                },
                complete: function() {
                    $('#btnSalvarVisitante').prop('disabled', false).html('<i class="fas fa-save"></i> Cadastrar Visitante');
                }
            });
        });
        
        // Cadastro de Profissional Renner
        $('#btnSalvarProfissional').click(function() {
            const formData = $('#formProfissional').serialize();
            const nome = $('#profissional_nome').val().trim();
            
            if (!nome) {
                showToast('Nome é obrigatório', 'error');
                return;
            }
            
            $(this).prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Salvando...');
            
            $.ajax({
                url: '/profissionais-renner?action=save_ajax',
                method: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showToast('Profissional cadastrado com sucesso!');
                        $('#modalProfissional').modal('hide');
                        limparFormulario('formProfissional');
                        setTimeout(() => window.location.reload(), 500);
                    } else {
                        showToast(response.message || 'Erro ao cadastrar profissional', 'error');
                    }
                },
                error: function(xhr, status, error) {
                    if (xhr.status === 401) {
                        showToast('Sessão expirada. Você será redirecionado para o login.', 'error');
                        setTimeout(() => {
                            window.location.href = '/login';
                        }, 2000);
                    } else {
                        showToast('Erro na comunicação com o servidor', 'error');
                    }
                },
                complete: function() {
                    $('#btnSalvarProfissional').prop('disabled', false).html('<i class="fas fa-save"></i> Cadastrar Profissional');
                }
            });
        });
        
        // Cadastro de Prestador de Serviço
        $('#btnSalvarPrestador').click(function() {
            const formData = $('#formPrestador').serialize();
            const nome = $('#prestador_nome').val().trim();
            const funcionario_responsavel = $('#prestador_funcionario_responsavel').val().trim();
            
            if (!nome) {
                showToast('Nome é obrigatório', 'error');
                return;
            }
            
            if (!funcionario_responsavel) {
                showToast('Funcionário Responsável é obrigatório', 'error');
                return;
            }
            
            $(this).prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Salvando...');
            
            $.ajax({
                url: '/prestadores-servico?action=save_ajax',
                method: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showToast('Prestador cadastrado com sucesso!');
                        $('#modalPrestador').modal('hide');
                        limparFormulario('formPrestador');
                        setTimeout(() => window.location.reload(), 500);
                    } else {
                        // Tratamento melhorado para erros de duplicidade
                        if (response.errors && Array.isArray(response.errors)) {
                            const mensagens = response.errors.join('<br>');
                            showToast(`⚠️ Problema de duplicidade:<br><small>${mensagens}</small>`, 'error');
                        } else {
                            showToast(response.message || 'Erro ao cadastrar prestador', 'error');
                        }
                    }
                },
                error: function(xhr, status, error) {
                    if (xhr.status === 401) {
                        showToast('Sessão expirada. Você será redirecionado para o login.', 'error');
                        setTimeout(() => {
                            window.location.href = '/login';
                        }, 2000);
                    } else {
                        showToast('Erro na comunicação com o servidor', 'error');
                    }
                },
                complete: function() {
                    $('#btnSalvarPrestador').prop('disabled', false).html('<i class="fas fa-save"></i> Cadastrar Prestador');
                }
            });
        });
        
        // Função para obter data/hora atual no timezone de São Paulo
        function obterDataHoraAtual() {
            const agora = new Date();
            
            // Usar Intl.DateTimeFormat para obter componentes no timezone de São Paulo
            const formatter = new Intl.DateTimeFormat('en-CA', {
                timeZone: 'America/Sao_Paulo',
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                hour12: false
            });
            
            const parts = formatter.formatToParts(agora);
            const date = parts.find(p => p.type === 'year').value + '-' +
                        parts.find(p => p.type === 'month').value + '-' +
                        parts.find(p => p.type === 'day').value;
            const time = parts.find(p => p.type === 'hour').value + ':' +
                        parts.find(p => p.type === 'minute').value;
            
            return `${date}T${time}`;
        }

        // Preencher campos de hora quando modais são abertos
        $('#modalVisitante').on('show.bs.modal', function() {
            $('#visitante_hora_entrada').val(obterDataHoraAtual());
        });

        $('#modalProfissional').on('show.bs.modal', function() {
            $('#profissional_data_entrada').val(obterDataHoraAtual());
            $('#profissional_observacao_container').hide();
            $('#profissional_observacao').val('');
        });

        // Detectar entrada retroativa e mostrar campo de observação
        $('#profissional_data_entrada').on('change', function() {
            const dataEntradaSelecionada = new Date($(this).val());
            const agora = new Date();
            
            // Se a data selecionada é anterior à data atual (retroativa)
            if (dataEntradaSelecionada < agora) {
                $('#profissional_observacao_container').slideDown();
                $('#profissional_observacao').attr('required', true);
            } else {
                $('#profissional_observacao_container').slideUp();
                $('#profissional_observacao').attr('required', false).val('');
            }
        });

        $('#modalPrestador').on('show.bs.modal', function() {
            $('#prestador_entrada').val(obterDataHoraAtual());
        });

        // Limpar formulários ao fechar modals
        $('.modal').on('hidden.bs.modal', function() {
            const modalId = $(this).attr('id');
            if (modalId === 'modalVisitante') {
                limparFormulario('formVisitante');
            } else if (modalId === 'modalProfissional') {
                limparFormulario('formProfissional');
            } else if (modalId === 'modalPrestador') {
                limparFormulario('formPrestador');
            }
        });

        // Função para aplicar filtros combinados
        function aplicarFiltros() {
            const valorTexto = $('#filtro-pessoas').val().toLowerCase();
            const tipoSelecionado = $('#filtro-tipo').val();
            
            $('.table tbody tr').each(function() {
                const linha = $(this);
                const textoLinha = linha.text().toLowerCase();
                const tipoLinha = linha.find('.badge').text().trim();
                
                let mostrarTexto = true;
                let mostrarTipo = true;
                
                // Filtro por texto (se houver)
                if (valorTexto.length >= 2) {
                    mostrarTexto = textoLinha.includes(valorTexto);
                }
                
                // Filtro por tipo (se houver)
                if (tipoSelecionado) {
                    mostrarTipo = tipoLinha === tipoSelecionado;
                }
                
                // Mostrar linha apenas se passar em ambos os filtros
                if (mostrarTexto && mostrarTipo) {
                    linha.show();
                } else {
                    linha.hide();
                }
            });
        }

        // Filtro por texto
        $('#filtro-pessoas').on('keyup', aplicarFiltros);
        
        // Filtro por tipo
        $('#filtro-tipo').on('change', aplicarFiltros);

        // Limpar todos os filtros
        $('#limpar-filtros').on('click', function() {
            $('#filtro-pessoas').val('');
            $('#filtro-tipo').val('');
            $('.table tbody tr').show();
        });

        // Edição inline de registros
        $(document).on('click', '.btn-editar', function() {
            const btn = $(this);
            const id = btn.data('id');
            const tipo = btn.data('tipo');
            const nome = btn.data('nome');
            const cpf = btn.data('cpf');
            const doc_type = btn.data('doc_type');  // MANTÉM underscore! jQuery não converte este atributo
            const doc_number = btn.data('doc_number');  // MANTÉM underscore! jQuery não converte este atributo
            const doc_country = btn.data('doc_country');  // MANTÉM underscore! jQuery não converte este atributo
            const empresa = btn.data('empresa');
            const setor = btn.data('setor');
            const funcionario = btn.attr('data-funcionario_responsavel') || '';  // Usar attr() é mais confiável
            const placa_veiculo = btn.data('placa_veiculo');  // MANTÉM underscore! jQuery não converte este atributo
            
            // Preencher campos básicos
            $('#edit_id').val(id);
            $('#edit_tipo_original').val(tipo);
            $('#edit_tipo_display').text(tipo);
            $('#edit_nome').val(nome);
            $('#edit_cpf').val(cpf); // Campo oculto para compatibilidade
            
            // Preencher campos de documento
            $('#edit_doc_type').val(doc_type || '');
            
            // Remover qualquer máscara antiga antes de preencher
            const docNumberField = $('#edit_doc_number');
            if (docNumberField.data('mask')) {
                docNumberField.unmask();
            }
            
            docNumberField.val(doc_number || cpf || ''); // Fallback para CPF legado
            $('#edit_doc_country').val(doc_country || '');
            
            // Mostrar campo país se for documento internacional
            if (doc_type && !['CPF', 'RG', 'CNH', ''].includes(doc_type)) {
                $('#edit_country_container').show();
            } else {
                $('#edit_country_container').hide();
            }
            
            $('#edit_empresa').val(empresa);
            $('#edit_setor').val(setor);
            $('#edit_placa_veiculo').val(placa_veiculo);
            
            // Verificar se é APE e marcar checkbox imediatamente
            if (placa_veiculo === 'APE') {
                $('#edit_ape_checkbox').prop('checked', true);
                $('#edit_placa_veiculo').prop('readonly', true);
            } else {
                $('#edit_ape_checkbox').prop('checked', false);
                $('#edit_placa_veiculo').prop('readonly', false);
            }
            
            // Mostrar/ocultar campos específicos baseado no tipo
            $('#campo_funcionario_responsavel, #campo_hora_saida, #campo_observacao, #campos_profissional_renner, #campos_documento').hide();
            
            // Mostrar campo de hora de saída para todos os tipos
            $('#campo_hora_saida').show();
            
            // Mostrar/ocultar campos específicos para Profissional Renner
            if (tipo === 'Profissional Renner') {
                $('#campo_empresa').hide();
                $('#campos_documento').hide();
                // Manter placa visível para Profissionais Renner
                $('#campo_placa_veiculo').show();
                // Mostrar campos específicos M2: saida e retorno
                $('#campos_profissional_renner').show();
                // Alterar cor do header do modal para Profissional Renner
                $('.modal-header').removeClass('bg-info').addClass('bg-primary');
                
                // Buscar dados do profissional para verificar se é entrada retroativa
                console.log('🔍 Buscando dados do profissional ID:', id);
                $.ajax({
                    url: `/profissionais-renner?action=get_data&id=${id}`,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        console.log('✅ Resposta do servidor:', response);
                        if (response.success) {
                            // Preencher saída e retorno se existirem
                            if (response.data.saida) {
                                const saidaFormatada = response.data.saida.replace(' ', 'T').slice(0, 16);
                                $('#edit_saida').val(saidaFormatada);
                            }
                            if (response.data.retorno) {
                                const retornoFormatado = response.data.retorno.replace(' ', 'T').slice(0, 16);
                                $('#edit_retorno').val(retornoFormatado);
                            }
                            if (response.data.saida_final) {
                                const saidaFinalFormatada = response.data.saida_final.replace(' ', 'T').slice(0, 16);
                                $('#edit_hora_saida').val(saidaFinalFormatada);
                            }
                            
                            // Verificar se é entrada retroativa e mostrar observação
                            console.log('🔍 is_retroativa:', response.data.is_retroativa);
                            console.log('🔍 observacao_retroativa:', response.data.observacao_retroativa);
                            
                            if (response.data.is_retroativa || response.data.observacao_retroativa) {
                                console.log('✅ Mostrando campo de observação retroativa');
                                $('#edit_profissional_observacao_container').show();
                                $('#edit_profissional_observacao').val(response.data.observacao_retroativa || '');
                            } else {
                                console.log('❌ Não é entrada retroativa, escondendo campo');
                                $('#edit_profissional_observacao_container').hide();
                            }
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('❌ Erro ao buscar dados:', error, xhr.responseText);
                        // Em caso de erro, esconder observação
                        $('#edit_profissional_observacao_container').hide();
                    }
                });
            } else {
                $('#campo_empresa').show();
                $('#campo_cpf').show();
                $('#campo_placa_veiculo').show();
                // Manter cor padrão do header para outros tipos
                $('.modal-header').removeClass('bg-primary').addClass('bg-info');
            }
            
            if (tipo === 'Visitante') {
                $('#campo_funcionario_responsavel').show();
                $('#campos_documento').show();
                // Preencher campos específicos do visitante
                $('#edit_funcionario_responsavel').val(funcionario || '');
                
                // Buscar dados completos do visitante para preencher hora de saída e foto
                console.log('🔍 Buscando dados do visitante ID:', id);
                $.ajax({
                    url: `/visitantes?action=get_data&id=${id}`,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        console.log('📦 Resposta recebida:', response);
                        if (response.success) {
                            if (response.data.hora_saida) {
                                // Formatar data para datetime-local sem conversão de timezone
                                const horaSaidaFormatada = response.data.hora_saida.replace(' ', 'T').slice(0, 16);
                                $('#edit_hora_saida').val(horaSaidaFormatada);
                            }
                            
                            // 📸 Exibir foto se disponível
                            console.log('🖼️ foto_url:', response.data.foto_url);
                            if (response.data.foto_url) {
                                console.log('✅ Exibindo foto:', response.data.foto_url);
                                $('#edit-foto-preview').attr('src', response.data.foto_url);
                                $('#edit-photo-display').show();
                            } else {
                                console.log('❌ Sem foto_url, escondendo display');
                                $('#edit-photo-display').hide();
                            }
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('❌ Erro ao buscar dados:', error, xhr.responseText);
                        // Em caso de erro, deixa o campo vazio
                        $('#edit_hora_saida').val('');
                        $('#edit-photo-display').hide();
                    }
                });
            } else if (tipo === 'Prestador') {
                $('#campo_funcionario_responsavel').show();
                $('#campo_observacao').show();
                $('#campos_documento').show();
                // Preencher campos específicos do prestador
                $('#edit_funcionario_responsavel').val(funcionario || '');
                $('#edit_observacao').val('');
                
                $.ajax({
                    url: `/prestadores-servico?action=get_data&id=${id}`,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            if (response.data.saida) {
                                // Formatar data para datetime-local sem conversão de timezone
                                const saidaFormatada = response.data.saida.replace(' ', 'T').slice(0, 16);
                                $('#edit_hora_saida').val(saidaFormatada);
                            }
                            if (response.data.observacao) {
                                $('#edit_observacao').val(response.data.observacao);
                            }
                            
                            // 📸 Exibir foto se disponível
                            if (response.data.foto_url) {
                                $('#edit-foto-preview').attr('src', response.data.foto_url);
                                $('#edit-photo-display').show();
                            } else {
                                $('#edit-photo-display').hide();
                            }
                        }
                    },
                    error: function() {
                        // Em caso de erro, deixa o campo vazio
                        $('#edit_hora_saida').val('');
                        $('#edit-photo-display').hide();
                    }
                });
            } else if (tipo === 'Profissional Renner') {
                // Buscar dados específicos do profissional para preencher todos os campos M2
                $.ajax({
                    url: `/profissionais-renner?action=get_data&id=${id}`,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if (response.success && response.data) {
                            // Preencher saída final (campo hora_saida)
                            if (response.data.saida_final) {
                                const saidaFinalFormatada = response.data.saida_final.replace(' ', 'T').slice(0, 16);
                                $('#edit_hora_saida').val(saidaFinalFormatada);
                            }
                            // Preencher saída intermediária (campo M2)
                            if (response.data.saida) {
                                const saidaFormatada = response.data.saida.replace(' ', 'T').slice(0, 16);
                                $('#edit_saida').val(saidaFormatada);
                            }
                            // Preencher retorno (campo M2)
                            if (response.data.retorno) {
                                const retornoFormatado = response.data.retorno.replace(' ', 'T').slice(0, 16);
                                $('#edit_retorno').val(retornoFormatado);
                            }
                        }
                    },
                    error: function() {
                        // Em caso de erro, deixa os campos vazios
                        $('#edit_hora_saida').val('');
                        $('#edit_saida').val('');
                        $('#edit_retorno').val('');
                    }
                });
            }
            
            // Abrir modal
            const modalElement = document.getElementById('modalEditar');
            const modal = new bootstrap.Modal(modalElement);
            modal.show();
        });

        // Salvar edição (apenas editar dados, sem saída)
        $('#btnSalvarEdicao').on('click', function() {
            const nome = $('#edit_nome').val().trim();
            const tipoOriginal = $('#edit_tipo_original').val();
            
            if (!nome) {
                showToast('Nome é obrigatório', 'error');
                return;
            }
            
            $(this).prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Salvando...');
            
            // Coletar dados comuns do formulário
            const dadosComuns = {
                id: $('#edit_id').val(),
                nome: $('#edit_nome').val(),
                cpf: $('#edit_cpf').val(),
                doc_type: $('#edit_doc_type').val() || '',
                doc_number: $('#edit_doc_number').val() || '',
                doc_country: $('#edit_doc_country').val() || 'Brasil',
                setor: $('#edit_setor').val(),
                csrf_token: $('meta[name="csrf-token"]').attr('content') || '<?= CSRFProtection::generateToken() ?>'
            };
            
            // Adicionar empresa apenas se não for Profissional Renner
            if (tipoOriginal !== 'Profissional Renner') {
                dadosComuns.empresa = $('#edit_empresa').val();
            }
            
            // Placa de veículo é obrigatória para todos os tipos
            dadosComuns.placa_veiculo = $('#edit_placa_veiculo').val();
            
            let formData = new FormData();
            let endpoint = '';
            
            // Adicionar dados comuns (incluindo campos vazios)
            Object.keys(dadosComuns).forEach(key => {
                formData.append(key, dadosComuns[key] || '');
            });
            
            // Determinar endpoint e campos específicos baseado no tipo
            const horaSaida = $('#edit_hora_saida').val();
            
            switch (tipoOriginal) {
                case 'Visitante':
                    endpoint = '/visitantes?action=update_ajax';
                    formData.append('funcionario_responsavel', $('#edit_funcionario_responsavel').val());
                    if (horaSaida) {
                        formData.append('hora_saida', horaSaida);
                    }
                    break;
                case 'Profissional Renner':
                    endpoint = '/profissionais-renner?action=update_ajax';
                    if (horaSaida) {
                        formData.append('saida_final', horaSaida); // Para Profissional Renner, hora de saída = saída final
                    }
                    // Adicionar campos M2: saída intermediária e retorno
                    const saidaIntermediaria = $('#edit_saida').val();
                    const retorno = $('#edit_retorno').val();
                    if (saidaIntermediaria) {
                        formData.append('saida', saidaIntermediaria);
                    }
                    if (retorno) {
                        formData.append('retorno', retorno);
                    }
                    break;
                case 'Prestador':
                    endpoint = '/prestadores-servico?action=update_ajax';
                    formData.append('funcionario_responsavel', $('#edit_funcionario_responsavel').val());
                    formData.append('observacao', $('#edit_observacao').val());
                    if (horaSaida) {
                        formData.append('saida', horaSaida);
                    }
                    break;
                default:
                    showToast('Tipo de registro inválido', 'error');
                    $(this).prop('disabled', false).html('<i class="fas fa-save"></i> Salvar Alterações');
                    return;
            }
            
            $.ajax({
                url: endpoint,
                method: 'POST',
                data: formData,
                dataType: 'json',
                processData: false,  // Não processar os dados automáticamente
                contentType: false,  // Deixar o browser definir o content-type
                success: function(response) {
                    if (response.success) {
                        showToast('Registro atualizado com sucesso!');
                        $('#modalEditar').modal('hide');
                        // Recarregar página para atualizar o dashboard
                        setTimeout(() => window.location.reload(), 500);
                    } else {
                        // Tratamento melhorado para erros de duplicidade
                        if (response.errors && Array.isArray(response.errors)) {
                            const mensagens = response.errors.join('<br>');
                            showToast(`⚠️ Problema de duplicidade:<br><small>${mensagens}</small>`, 'error');
                        } else {
                            showToast(response.message || 'Erro ao atualizar registro', 'error');
                        }
                    }
                },
                error: function(xhr, status, error) {
                    if (xhr.status === 401) {
                        showToast('Sessão expirada. Você será redirecionado para o login.', 'error');
                        setTimeout(() => {
                            window.location.href = '/login';
                        }, 2000);
                    } else {
                        showToast('Erro na comunicação com o servidor', 'error');
                    }
                },
                complete: function() {
                    $('#btnSalvarEdicao').prop('disabled', false).html('<i class="fas fa-save"></i> Salvar Alterações');
                }
            });
        });



        // Limpar formulário de edição ao fechar modal
        $('#modalEditar').on('hidden.bs.modal', function() {
            $('#formEditar')[0].reset();
            $('#campo_funcionario_responsavel, #campo_hora_saida, #campo_observacao, #campos_profissional_renner, #edit-photo-display').hide();
            $('#edit-foto-preview').attr('src', '');
        });

        // ==================== MÁSCARAS DE ENTRADA - BOOTSTRAP 4.6.2 COMPATÍVEL ====================
        
        console.log('✅ Sistema de máscaras carregado (Bootstrap 4.6.2)');
        
        // Máscara para CPF - Formato: 000.000.000-00
        function aplicarMascaraCPF(selector) {
            $(selector).on('input paste keyup', function() {
                let cpf = this.value.replace(/\D/g, ''); // Remove não-dígitos
                cpf = cpf.substring(0, 11); // Limita a 11 dígitos
                
                // Aplica formatação progressiva
                cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
                cpf = cpf.replace(/(\d{3})\.(\d{3})(\d)/, '$1.$2.$3');
                cpf = cpf.replace(/(\d{3})\.(\d{3})\.(\d{3})(\d)/, '$1.$2.$3-$4');
                
                this.value = cpf;
            });
        }
        
        // Máscara para Placa - Formatos: ABC-1234 (antigo) e ABC1D23 (Mercosul)
        function aplicarMascaraPlaca(selector) {
            $(selector).on('input paste keyup', function() {
                let placa = this.value.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
                placa = placa.substring(0, 7); // Máximo 7 caracteres
                
                // Detecta formato e aplica formatação
                if (placa.length >= 4) {
                    const letras = placa.substring(0, 3);
                    const resto = placa.substring(3);
                    
                    // Se primeiros 3 são letras
                    if (/^[A-Z]{3}$/.test(letras)) {
                        // Se resto são só números = formato antigo ABC-1234
                        if (/^[0-9]+$/.test(resto)) {
                            placa = letras + '-' + resto;
                        }
                        // Senão = formato Mercosul ABC1D23 (sem formatação extra)
                    }
                }
                
                this.value = placa;
            });
        }
        
        // ==================== SELETOR DE TIPO DE DOCUMENTO ====================
        
        function setupDocumentSelector(prefix) {
            const $docType = $(`#${prefix}_doc_type`);
            const $docNumber = $(`#${prefix}_doc_number`);
            const $docCountry = $(`#${prefix}_doc_country`);
            const $countryContainer = $(`#${prefix}_country_container`);
            const $cpfLegacy = $(`#${prefix}_cpf`);
            
            // Função centralizada: normalizar tipo vazio como CPF
            function getEffectiveDocType() {
                return ($docType.val() || 'CPF').toUpperCase();
            }
            
            // Aplicar máscara conforme tipo de documento
            function applyDocumentMask() {
                const docType = getEffectiveDocType(); // Usar função centralizada
                let value = $docNumber.val().replace(/\D/g, ''); // Remove formatação
                
                // Tipo CPF (incluindo quando vazio/padrão)
                if (docType === 'CPF') {
                    // Máscara CPF: 000.000.000-00
                    value = value.substring(0, 11);
                    value = value.replace(/(\d{3})(\d)/, '$1.$2');
                    value = value.replace(/(\d{3})\.(\d{3})(\d)/, '$1.$2.$3');
                    value = value.replace(/(\d{3})\.(\d{3})\.(\d{3})(\d)/, '$1.$2.$3-$4');
                    // SEMPRE sincronizar com campo CPF legado quando tipo = CPF ou vazio
                    $cpfLegacy.val(value.replace(/\D/g, ''));
                } else if (docType === 'RG') {
                    // Máscara RG: 00.000.000-0
                    value = $docNumber.val().replace(/[^0-9X]/gi, '').toUpperCase().substring(0, 9);
                    value = value.replace(/(\d{2})(\d)/, '$1.$2');
                    value = value.replace(/(\d{3})(\d)/, '$1.$2');
                    value = value.replace(/(\d{3})(\d{1})$/, '$1-$2');
                } else if (docType === 'CNH') {
                    // CNH: apenas números, 11 dígitos
                    value = value.substring(0, 11);
                } else {
                    // Outros: sem máscara, aceita alfanumérico
                    value = $docNumber.val().replace(/[^A-Z0-9]/gi, '').toUpperCase();
                }
                
                $docNumber.val(value);
                
                // Mostrar campo país para documentos internacionais
                if (['PASSAPORTE', 'RNE', 'DNI', 'CI', 'OUTRO'].indexOf(docType) !== -1) {
                    $countryContainer.show();
                } else {
                    $countryContainer.hide();
                    $docCountry.val('BR');
                }
            }
            
            // Eventos
            $docType.on('change', applyDocumentMask);
            $docNumber.on('input paste keyup blur', applyDocumentMask);
            
            // Garantir sincronização antes do submit
            $(`#form${prefix.charAt(0).toUpperCase() + prefix.slice(1)}`).on('submit', function() {
                applyDocumentMask(); // Forçar sincronização final
            });
            
            // Aplicar na inicialização
            applyDocumentMask();
        }
        
        // ==================== MÁSCARAS MODAL DE EDIÇÃO ====================
        function toggleEditCountryField() {
            const docType = $('#edit_doc_type').val();
            if (docType && !['CPF', 'RG', 'CNH', ''].includes(docType)) {
                $('#edit_country_container').show();
            } else {
                $('#edit_country_container').hide();
            }
        }
        
        function applyEditDocumentMask() {
            const docType = $('#edit_doc_type').val() || 'CPF';
            const $docNumber = $('#edit_doc_number');
            
            // Remover máscara anterior
            if ($docNumber.data('mask')) {
                $docNumber.unmask();
            }
            
            // Aplicar máscara baseada no tipo
            if (docType === 'CPF' || docType === '') {
                $docNumber.mask('000.000.000-00', {
                    reverse: false,
                    clearIfNotMatch: true,
                    onChange: function(value) {
                        const cleanValue = value.replace(/\D/g, '');
                        console.log('CPF edit limpo:', cleanValue);
                    }
                });
            } else if (docType === 'RG') {
                $docNumber.mask('0000000000', {
                    reverse: false,
                    clearIfNotMatch: true,
                    onChange: function(value) {
                        const cleanValue = value.replace(/\D/g, '');
                        console.log('RG edit limpo:', cleanValue);
                    }
                });
            } else if (docType === 'CNH') {
                $docNumber.mask('00000000000');
            } else {
                // Documentos internacionais: sem máscara
                $docNumber.attr('maxlength', 20);
            }
        }
        
        $('#edit_doc_type').on('change', function() {
            toggleEditCountryField();
            applyEditDocumentMask();
        });
        
        // Aplicar máscaras quando os modais abrem
        $('#modalVisitante').on('shown.bs.modal', function() {
            setupDocumentSelector('visitante');
            aplicarMascaraPlaca('#visitante_placa_veiculo');
            console.log('✅ Seletor de documentos aplicado ao Modal Visitante');
            
            // Controle do checkbox "A pé" para visitante
            let previousValueVisitante = '';
            
            $('#visitante_ape_checkbox').off('change').on('change', function() {
                if ($(this).is(':checked')) {
                    previousValueVisitante = $('#visitante_placa_veiculo').val() !== 'APE' ? $('#visitante_placa_veiculo').val() : '';
                    $('#visitante_placa_veiculo').val('APE').prop('readonly', true).removeAttr('required');
                } else {
                    $('#visitante_placa_veiculo').val(previousValueVisitante).prop('readonly', false).attr('required', 'required');
                }
            });
            
            // Verificar estado inicial
            if ($('#visitante_placa_veiculo').val() === 'APE') {
                $('#visitante_ape_checkbox').prop('checked', true);
                $('#visitante_placa_veiculo').prop('readonly', true);
            }
        });
        
        $('#modalPrestador').on('shown.bs.modal', function() {
            aplicarMascaraPlaca('#prestador_placa_veiculo');
            console.log('✅ Máscaras aplicadas ao Modal Prestador');
            
            // Controle de tipo de documento e máscaras dinâmicas
            function togglePrestadorCountryField() {
                const docType = $('#prestador_doc_type').val();
                const internationalDocs = ['Passaporte', 'RNE', 'DNI', 'CI', 'Outros'];
                
                if (internationalDocs.includes(docType)) {
                    $('#prestador_country_container').show();
                    $('#prestador_doc_country').attr('required', 'required');
                } else {
                    $('#prestador_country_container').hide();
                    $('#prestador_doc_country').val('Brasil').removeAttr('required');
                }
            }
            
            function applyPrestadorDocumentMask() {
                const docType = $('#prestador_doc_type').val() || 'CPF';
                const $docNumber = $('#prestador_doc_number');
                
                // Remover máscara anterior
                $docNumber.unmask();
                
                // Aplicar nova máscara
                if (docType === 'CPF' || docType === '') {
                    $docNumber.mask('000.000.000-00', {reverse: true});
                } else if (docType === 'RG') {
                    $docNumber.mask('00.000.000-A', {
                        translation: {
                            'A': {pattern: /[0-9Xx]/, optional: true}
                        }
                    });
                } else if (docType === 'CNH') {
                    $docNumber.mask('00000000000');
                } else {
                    // Documentos internacionais: sem máscara
                    $docNumber.attr('maxlength', 20);
                }
                
                // Sincronizar com CPF oculto
                if (docType === 'CPF' || docType === '') {
                    $('#prestador_cpf').val($docNumber.val());
                }
            }
            
            $('#prestador_doc_type').on('change', function() {
                togglePrestadorCountryField();
                applyPrestadorDocumentMask();
            });
            
            $('#prestador_doc_number').on('input', function() {
                const docType = $('#prestador_doc_type').val() || 'CPF';
                if (docType === 'CPF' || docType === '') {
                    $('#prestador_cpf').val($(this).val());
                }
            });
            
            // Inicializar
            togglePrestadorCountryField();
            applyPrestadorDocumentMask();
            
            // Controle do checkbox "A pé" para prestador
            let previousValuePrestador = '';
            
            $('#prestador_ape_checkbox').off('change').on('change', function() {
                if ($(this).is(':checked')) {
                    previousValuePrestador = $('#prestador_placa_veiculo').val() !== 'APE' ? $('#prestador_placa_veiculo').val() : '';
                    $('#prestador_placa_veiculo').val('APE').prop('readonly', true).removeAttr('required');
                } else {
                    $('#prestador_placa_veiculo').val(previousValuePrestador).prop('readonly', false).attr('required', 'required');
                }
            });
            
            // Verificar estado inicial
            if ($('#prestador_placa_veiculo').val() === 'APE') {
                $('#prestador_ape_checkbox').prop('checked', true);
                $('#prestador_placa_veiculo').prop('readonly', true);
            }
        });
        
        $('#modalProfissional').on('shown.bs.modal', function() {
            aplicarMascaraPlaca('#profissional_placa_veiculo');
            console.log('✅ Máscaras aplicadas ao Modal Profissional');
            
            // Garantir que o campo de placa esteja habilitado inicialmente
            $('#profissional_placa_veiculo').prop('readonly', false).prop('disabled', false);
            $('#profissional_ape_checkbox').prop('checked', false);
            
            // Autocomplete para o campo Nome
            if ($('#profissional_nome').autocomplete('instance')) {
                $('#profissional_nome').autocomplete('destroy');
            }
            
            $('#profissional_nome').autocomplete({
                source: function(request, response) {
                    $.ajax({
                        url: '/profissionais-renner?action=search',
                        dataType: 'json',
                        data: {
                            q: request.term
                        },
                        success: function(data) {
                            if (data.success && data.data) {
                                const items = $.map(data.data, function(item) {
                                    return {
                                        label: item.nome + ' - ' + item.setor,
                                        value: item.nome,
                                        setor: item.setor,
                                        fre: item.fre
                                    };
                                });
                                response(items);
                            } else {
                                response([]);
                            }
                        },
                        error: function() {
                            response([]);
                        }
                    });
                },
                minLength: 2,
                select: function(event, ui) {
                    $('#profissional_nome').val(ui.item.value);
                    $('#profissional_setor').val(ui.item.setor);
                    return false;
                }
            });
            
            // Controle do checkbox "A pé" para Profissional Renner
            let previousValueProfissional = '';
            
            $('#profissional_ape_checkbox').off('change').on('change', function() {
                if ($(this).is(':checked')) {
                    previousValueProfissional = $('#profissional_placa_veiculo').val() !== 'APE' ? $('#profissional_placa_veiculo').val() : '';
                    $('#profissional_placa_veiculo').val('APE').prop('readonly', true).removeAttr('required');
                } else {
                    $('#profissional_placa_veiculo').val(previousValueProfissional).prop('readonly', false).attr('required', 'required');
                }
            });
            
            // Verificar estado inicial
            if ($('#profissional_placa_veiculo').val() === 'APE') {
                $('#profissional_ape_checkbox').prop('checked', true);
                $('#profissional_placa_veiculo').prop('readonly', true);
            }
        });
        
        $('#modalEditar').on('shown.bs.modal', function() {
            aplicarMascaraPlaca('#edit_placa_veiculo');
            applyEditDocumentMask();
            console.log('✅ Máscaras aplicadas ao Modal Editar (placa e documento)');
            
            // Controle do checkbox "A pé" para modal de edição
            let previousValueEdit = '';
            
            $('#edit_ape_checkbox').off('change').on('change', function() {
                if ($(this).is(':checked')) {
                    previousValueEdit = $('#edit_placa_veiculo').val() !== 'APE' ? $('#edit_placa_veiculo').val() : '';
                    $('#edit_placa_veiculo').val('APE').prop('readonly', true).removeAttr('required');
                } else {
                    $('#edit_placa_veiculo').val(previousValueEdit).prop('readonly', false).attr('required', 'required');
                }
            });
            
            // Verificar estado inicial
            if ($('#edit_placa_veiculo').val() === 'APE') {
                $('#edit_ape_checkbox').prop('checked', true);
                $('#edit_placa_veiculo').prop('readonly', true);
            }
        });
        
        console.log('🎯 Sistema de máscaras inicializado com Bootstrap 4.6.2!');
        
        // ===================================
        // WIDGET: Renovação de Cadastros (v2.0.0)
        // ===================================
        $(document).on('click', '.renovar-cadastro', function() {
            const tipo = $(this).data('tipo');
            const id = $(this).data('id');
            const nome = $(this).data('nome');
            
            if (!confirm(`Deseja renovar o cadastro de ${nome} por mais 30 dias?`)) {
                return;
            }
            
            const btn = $(this);
            btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Renovando...');
            
            // Calcular nova data (30 dias a partir de hoje)
            const novaValidade = new Date();
            novaValidade.setDate(novaValidade.getDate() + 30);
            const dataFormatada = novaValidade.toISOString().split('T')[0];
            
            // Endpoint depende do tipo
            const endpoint = tipo === 'visitante' ? '/visitantes' : '/prestadores-servico';
            
            $.ajax({
                url: `${endpoint}?action=update`,
                method: 'PUT',
                headers: {
                    'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
                },
                contentType: 'application/json',
                data: JSON.stringify({
                    id: id,
                    valid_until: dataFormatada,
                    validity_status: 'ativo'
                }),
                success: function(response) {
                    if (response.success) {
                        showToast(`Cadastro de ${nome} renovado até ${new Date(dataFormatada).toLocaleDateString('pt-BR')}!`, 'success');
                        // Recarregar a página após 1 segundo para atualizar o widget
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        showToast('Erro ao renovar cadastro: ' + (response.message || 'Erro desconhecido'), 'error');
                        btn.prop('disabled', false).html('<i class="fas fa-sync"></i> Renovar');
                    }
                },
                error: function(xhr) {
                    const errorMsg = xhr.responseJSON?.message || 'Erro ao conectar com o servidor';
                    showToast('Erro ao renovar: ' + errorMsg, 'error');
                    btn.prop('disabled', false).html('<i class="fas fa-sync"></i> Renovar');
                }
            });
        });
        
        // Auto-refresh do widget a cada 5 minutos (opcional)
        // setInterval(() => location.reload(), 5 * 60 * 1000);
        
    });
    </script>
    
    <?php
    // Incluir rodapé LGPD
    require_once __DIR__ . '/../components/lgpd-footer.php';
    
    // Banner de Cookies LGPD
    require_once BASE_PATH . '/src/services/CookieService.php';
    CookieService::includeBanner();
    ?>
</body>
</html>
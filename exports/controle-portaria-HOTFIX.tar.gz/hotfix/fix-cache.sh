#!/bin/bash
echo "🔧 Diagnóstico + Correção do Toggle de Usuários"
echo "================================================"

# 1. Verificar se atualização foi aplicada
echo ""
echo "📋 Verificando se código foi atualizado..."
docker exec controle-portaria-app-1 grep -c "filter_var.*ativo.*FILTER_VALIDATE_BOOLEAN" /var/www/html/src/controllers/ConfigController.php > /dev/null
if [ $? -eq 0 ]; then
    echo "✅ Código corrigido está presente no servidor"
else
    echo "❌ ERRO: Código ainda não foi atualizado! Execute UPDATE.sh novamente"
    exit 1
fi

# 2. Limpar cache do OPcache (pode estar servindo código antigo)
echo ""
echo "🧹 Limpando cache do PHP (OPcache)..."
docker exec controle-portaria-app-1 bash -c "echo '<?php opcache_reset(); echo \"Cache limpo!\"; ?>' > /var/www/html/public/clear-cache.php"
curl -s http://localhost:8080/clear-cache.php
docker exec controle-portaria-app-1 rm /var/www/html/public/clear-cache.php

# 3. Reiniciar Apache (força recarregar código)
echo ""
echo "🔄 Reiniciando Apache..."
docker-compose restart app

# 4. Aguardar container ficar pronto
echo ""
echo "⏳ Aguardando container inicializar..."
sleep 5

# 5. Testar conectividade
echo ""
echo "🧪 Testando conectividade..."
if curl -s http://localhost:8080 > /dev/null; then
    echo "✅ Aplicação está respondendo!"
else
    echo "❌ AVISO: Aplicação não está respondendo na porta 8080"
fi

echo ""
echo "✅ CORREÇÃO CONCLUÍDA!"
echo ""
echo "🧪 PRÓXIMO PASSO:"
echo "   1. Acesse: http://localhost:8080/config"
echo "   2. Vá na aba 'Usuários'"
echo "   3. Clique no toggle de um usuário (exceto ID=1)"
echo "   4. Se ainda der erro, envie screenshot + logs:"
echo "      docker-compose logs app --tail=50"

========================================

PROBLEMA ANTERIOR: Conversão PHP → PostgreSQL de boolean
SOLUÇÃO V2: SQL direto com NOT (compatibilidade 100%)

MUDANÇA:
--------
ANTES: UPDATE usuarios SET ativo = ? (com 'true'/'false')
AGORA:  UPDATE usuarios SET ativo = NOT ativo (SQL puro)

INSTALAÇÃO:
-----------
1. Extrair pacote:
   tar -xzf controle-portaria-UPDATE-v2.tar.gz
   cd update-v2

2. Executar atualização:
   ./UPDATE-v2.sh

3. Testar:
   http://localhost:8080/config → Usuários → Clicar no toggle

COMPATIBILIDADE:
----------------
✅ PostgreSQL 12, 13, 14, 15, 16
✅ Qualquer configuração de locale
✅ Docker + Ubuntu 24.04

ROLLBACK (se necessário):
-------------------------
docker cp /tmp/ConfigController.php.backup.v2.YYYYMMDD_HHMMSS \
  controle-portaria-app-1:/var/www/html/src/controllers/ConfigController.php
docker-compose restart app
